export type UserRole = "builder" | "institution" | "business" | "company" | "organization" | "verifier" | "admin"
export type ApplicationStatus = "pending" | "in_review" | "approved" | "rejected" | "needs_update"
export type ListingType = "physical" | "digital" | "tokenized" | "nft" | "tool" | "service" | "idea" | "talent"
export type DepartmentType =
  | "verification"
  | "institution"
  | "business"
  | "blockchain"
  | "reputation"
  | "tech"
  | "idea"
  | "talent"
  | "organization"

export interface Profile {
  id: string
  email: string
  full_name: string | null
  avatar_url: string | null
  role: UserRole
  bio: string | null
  wallet_address: string | null
  phone_number: string | null
  reputation_score: number
  is_verified: boolean
  created_at: string
  updated_at: string
}

export interface Department {
  id: string
  name: string
  type: DepartmentType
  description: string | null
  icon: string | null
  created_at: string
}

export interface Category {
  id: string
  name: string
  slug: string
  description: string | null
  parent_id: string | null
  icon: string | null
  created_at: string
}

export interface Application {
  id: string
  user_id: string
  application_type: UserRole
  title: string
  description: string
  documents: any[]
  status: ApplicationStatus
  department_id: string | null
  assigned_verifier_id: string | null
  feedback: string | null
  submitted_at: string
  reviewed_at: string | null
  created_at: string
  updated_at: string
}

export interface Listing {
  id: string
  user_id: string
  title: string
  description: string
  price: number | null
  listing_type: ListingType
  category_id: string | null
  images: string[]
  is_verified: boolean
  is_tokenized: boolean
  token_id: string | null
  contract_address: string | null
  metadata: Record<string, any>
  view_count: number
  created_at: string
  updated_at: string
  // Joined fields
  user?: Profile
  category?: Category
}

export interface Tool {
  id: string
  name: string
  description: string
  category: string
  icon: string | null
  url: string | null
  is_premium: boolean
  created_at: string
}

export interface ReputationLog {
  id: string
  user_id: string
  points: number
  reason: string
  event_type: string
  reference_id: string | null
  created_at: string
}

export interface Notification {
  id: string
  user_id: string
  title: string
  message: string
  type: string
  is_read: boolean
  reference_id: string | null
  created_at: string
}

export interface Program {
  id: string
  title: string
  description: string | null
  program_type: string
  start_date: string | null
  end_date: string | null
  capacity: number | null
  is_active: boolean
  created_at: string
}

export interface Event {
  id: string
  title: string
  description: string | null
  event_type: string
  start_date: string
  end_date: string | null
  location: string | null
  is_virtual: boolean
  max_attendees: number | null
  created_by: string | null
  created_at: string
}
