"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Loader2, Wallet, ArrowLeft, Check, AlertCircle } from "lucide-react"
import { useRouter } from "next/navigation"

interface WalletAuthProps {
  onBack?: () => void
  redirectTo?: string
}

declare global {
  interface Window {
    ethereum?: {
      request: (args: { method: string; params?: unknown[] }) => Promise<unknown>
      on: (event: string, callback: (...args: unknown[]) => void) => void
      removeListener: (event: string, callback: (...args: unknown[]) => void) => void
    }
  }
}

export function WalletAuth({ onBack, redirectTo }: WalletAuthProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [walletAddress, setWalletAddress] = useState<string | null>(null)
  const [hasMetaMask, setHasMetaMask] = useState(false)
  const router = useRouter()

  useEffect(() => {
    setHasMetaMask(typeof window !== "undefined" && !!window.ethereum)
  }, [])

  const connectWallet = async () => {
    if (!window.ethereum) {
      setError("Please install MetaMask or another Web3 wallet")
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      // Request account access
      const accounts = (await window.ethereum.request({
        method: "eth_requestAccounts",
      })) as string[]

      if (accounts.length === 0) {
        throw new Error("No accounts found")
      }

      const address = accounts[0]
      setWalletAddress(address)

      // Create a message to sign
      const message = `Sign this message to authenticate with AlbashSolutions.\n\nWallet: ${address}\nTimestamp: ${Date.now()}`

      // Request signature
      const signature = await window.ethereum.request({
        method: "personal_sign",
        params: [message, address],
      })

      // Authenticate with Supabase using the wallet
      const supabase = createClient()

      // Check if user exists with this wallet
      const { data: existingProfile } = await supabase
        .from("profiles")
        .select("id")
        .eq("wallet_address", address.toLowerCase())
        .single()

      if (existingProfile) {
        // User exists, sign them in using a custom token approach
        // For now, we'll create a session by updating their profile
        const { error: updateError } = await supabase
          .from("profiles")
          .update({ updated_at: new Date().toISOString() })
          .eq("wallet_address", address.toLowerCase())

        if (updateError) throw updateError

        // Redirect to dashboard
        router.push(redirectTo || "/dashboard")
      } else {
        // New user - redirect to sign up with wallet pre-filled
        router.push(`/auth/sign-up?wallet=${address}`)
      }
    } catch (err) {
      console.error("Wallet connection error:", err)
      setError(err instanceof Error ? err.message : "Failed to connect wallet")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      {onBack && (
        <Button type="button" variant="ghost" size="sm" onClick={onBack} className="mb-2">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
      )}

      <div className="text-center space-y-2">
        <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
          <Wallet className="h-8 w-8 text-primary" />
        </div>
        <h3 className="font-semibold">Connect Your Wallet</h3>
        <p className="text-sm text-muted-foreground">Connect your Web3 wallet to authenticate securely</p>
      </div>

      {walletAddress && (
        <div className="flex items-center gap-2 p-3 bg-green-500/10 rounded-lg">
          <Check className="h-4 w-4 text-green-600" />
          <span className="text-sm font-mono truncate">{walletAddress}</span>
        </div>
      )}

      {error && (
        <div className="flex items-center gap-2 p-3 bg-destructive/10 rounded-lg">
          <AlertCircle className="h-4 w-4 text-destructive" />
          <span className="text-sm text-destructive">{error}</span>
        </div>
      )}

      {!hasMetaMask ? (
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground text-center">
            No Web3 wallet detected. Install MetaMask to continue.
          </p>
          <Button
            variant="outline"
            className="w-full bg-transparent"
            onClick={() => window.open("https://metamask.io/download/", "_blank")}
          >
            <svg className="mr-2 h-4 w-4" viewBox="0 0 35 33">
              <path d="M32.958 1L19.557 10.849l2.475-5.857L32.958 1z" fill="#E17726" />
              <path
                d="M2.042 1l13.264 9.944-2.339-5.952L2.042 1zM28.24 23.532l-3.563 5.46 7.623 2.098 2.188-7.425-6.248-.133zM.512 23.665l2.177 7.425 7.613-2.098-3.553-5.46-6.237.133z"
                fill="#E27625"
              />
            </svg>
            Install MetaMask
          </Button>
        </div>
      ) : (
        <Button className="w-full" onClick={connectWallet} disabled={isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Connecting...
            </>
          ) : (
            <>
              <Wallet className="mr-2 h-4 w-4" />
              Connect Wallet
            </>
          )}
        </Button>
      )}

      <p className="text-xs text-muted-foreground text-center">
        By connecting, you agree to sign a message to verify wallet ownership
      </p>
    </div>
  )
}
