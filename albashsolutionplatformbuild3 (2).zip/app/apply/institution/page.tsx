import { ApplicationForm } from "@/components/apply/application-form"

export default function ApplyInstitutionPage() {
  return <ApplicationForm applicationType="institution" />
}
