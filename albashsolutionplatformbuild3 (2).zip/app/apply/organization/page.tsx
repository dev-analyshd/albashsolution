import { ApplicationForm } from "@/components/apply/application-form"

export default function ApplyOrganizationPage() {
  return <ApplicationForm applicationType="organization" />
}
