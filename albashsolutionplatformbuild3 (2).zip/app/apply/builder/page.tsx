import { ApplicationForm } from "@/components/apply/application-form"

export default function ApplyBuilderPage() {
  return <ApplicationForm applicationType="builder" />
}
