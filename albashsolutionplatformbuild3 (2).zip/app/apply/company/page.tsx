import { ApplicationForm } from "@/components/apply/application-form"

export default function ApplyCompanyPage() {
  return <ApplicationForm applicationType="company" />
}
