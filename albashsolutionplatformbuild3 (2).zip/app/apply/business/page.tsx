import { ApplicationForm } from "@/components/apply/application-form"

export default function ApplyBusinessPage() {
  return <ApplicationForm applicationType="business" />
}
