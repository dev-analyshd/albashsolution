"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Checkbox } from "@/components/ui/checkbox"
import { ArrowLeft, Upload, X, Loader2, Shield, CreditCard, Wallet, Banknote } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import Link from "next/link"
import useSWR from "swr"

const fetcher = (url: string) => fetch(url).then((res) => res.json())

const listingTypes = [
  { value: "physical", label: "Physical Product", description: "Tangible goods like crafts, food, clothing" },
  { value: "digital", label: "Digital Product", description: "Software, designs, documents, courses" },
  { value: "service", label: "Service", description: "Professional services, consulting, freelance work" },
  { value: "idea", label: "Idea / Innovation", description: "Business ideas, patents, concepts" },
  { value: "talent", label: "Talent / Skill", description: "Offer your skills and expertise" },
  { value: "tokenized", label: "Tokenized Asset", description: "NFT or blockchain-verified asset" },
]

const paymentMethods = [
  { id: "card", label: "Card Payment", icon: CreditCard, description: "Visa, Mastercard (via Paystack/Stripe)" },
  { id: "bank", label: "Bank Transfer", icon: Banknote, description: "Direct bank transfer (NGN/USD)" },
  { id: "crypto", label: "Cryptocurrency", icon: Wallet, description: "ETH, USDT, and other tokens" },
]

export default function NewListingPage() {
  const router = useRouter()
  const supabase = createClient()
  const [loading, setLoading] = useState(false)
  const [images, setImages] = useState<string[]>([])
  const [selectedPayments, setSelectedPayments] = useState<string[]>(["card", "bank"])
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    price: "",
    currency: "NGN",
    category_id: "",
    listing_type: "physical",
    is_tokenized: false,
  })

  const { data: categories } = useSWR("/api/categories", fetcher)

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    // For now, create object URLs (in production, upload to Supabase Storage)
    const urls = Array.from(files).map((file) => URL.createObjectURL(file))
    setImages((prev) => [...prev, ...urls].slice(0, 5))
  }

  const removeImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index))
  }

  const togglePayment = (id: string) => {
    setSelectedPayments((prev) => (prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) throw new Error("Not authenticated")

      // Create the listing (pending verification)
      const { data: listing, error: listingError } = await supabase
        .from("listings")
        .insert({
          title: formData.title,
          description: formData.description,
          price: formData.price ? Number.parseFloat(formData.price) : null,
          category_id: formData.category_id || null,
          listing_type: formData.listing_type,
          is_tokenized: formData.is_tokenized,
          is_verified: false, // Requires verification before public
          images,
          user_id: user.id,
          metadata: {
            currency: formData.currency,
            payment_methods: selectedPayments,
          },
        })
        .select()
        .single()

      if (listingError) throw listingError

      // Create an application for verification
      const { error: appError } = await supabase.from("applications").insert({
        user_id: user.id,
        application_type: "builder", // Or detect from profile
        title: `Listing Verification: ${formData.title}`,
        description: `Request to verify listing: ${formData.description.substring(0, 200)}...`,
        status: "pending",
        documents: [
          {
            type: "listing",
            listing_id: listing.id,
            images,
          },
        ],
      })

      if (appError) {
        console.error("Failed to create verification request:", appError)
      }

      router.push("/dashboard/listings")
      router.refresh()
    } catch (error) {
      console.error("Error creating listing:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/dashboard/listings">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold">Create New Listing</h1>
          <p className="text-muted-foreground mt-1">Add a product, service, or asset to the marketplace</p>
        </div>
      </div>

      <Alert>
        <Shield className="h-4 w-4" />
        <AlertTitle>Verification Required</AlertTitle>
        <AlertDescription>
          All listings go through our verification process before becoming public. This ensures quality and trust for
          all users.
        </AlertDescription>
      </Alert>

      <form onSubmit={handleSubmit}>
        <div className="space-y-6">
          {/* Images */}
          <Card>
            <CardHeader>
              <CardTitle>Images</CardTitle>
              <CardDescription>Add up to 5 images for your listing (first image is the cover)</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-5 gap-4">
                {images.map((url, index) => (
                  <div key={index} className="relative aspect-square rounded-lg overflow-hidden bg-muted">
                    <img src={url || "/placeholder.svg"} alt="" className="object-cover w-full h-full" />
                    <button
                      type="button"
                      onClick={() => removeImage(index)}
                      className="absolute top-1 right-1 p-1 rounded-full bg-background/80 hover:bg-background"
                    >
                      <X className="h-3 w-3" />
                    </button>
                    {index === 0 && (
                      <span className="absolute bottom-1 left-1 text-xs bg-primary text-primary-foreground px-1.5 py-0.5 rounded">
                        Cover
                      </span>
                    )}
                  </div>
                ))}
                {images.length < 5 && (
                  <label className="aspect-square rounded-lg border-2 border-dashed flex flex-col items-center justify-center cursor-pointer hover:border-primary transition-colors">
                    <Upload className="h-6 w-6 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground mt-1">Upload</span>
                    <input type="file" accept="image/*" multiple className="hidden" onChange={handleImageUpload} />
                  </label>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Listing Type</CardTitle>
              <CardDescription>What are you listing?</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3 sm:grid-cols-2">
                {listingTypes.map((type) => (
                  <div
                    key={type.value}
                    className={`p-4 rounded-lg border-2 cursor-pointer transition-colors ${
                      formData.listing_type === type.value
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50"
                    }`}
                    onClick={() => setFormData({ ...formData, listing_type: type.value })}
                  >
                    <p className="font-medium">{type.label}</p>
                    <p className="text-sm text-muted-foreground">{type.description}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Basic Info */}
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  placeholder="Enter a clear, descriptive title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Describe your listing in detail. Include features, specifications, and any relevant information..."
                  rows={6}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  required
                />
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="price">Price</Label>
                  <div className="flex gap-2">
                    <Select
                      value={formData.currency}
                      onValueChange={(value) => setFormData({ ...formData, currency: value })}
                    >
                      <SelectTrigger className="w-24">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="NGN">NGN</SelectItem>
                        <SelectItem value="USD">USD</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input
                      id="price"
                      type="number"
                      min="0"
                      step="0.01"
                      placeholder="0.00"
                      value={formData.price}
                      onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                      className="flex-1"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select
                    value={formData.category_id}
                    onValueChange={(value) => setFormData({ ...formData, category_id: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories?.map((cat: any) => (
                        <SelectItem key={cat.id} value={cat.id}>
                          {cat.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Payment Methods</CardTitle>
              <CardDescription>Select which payment methods you accept</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {paymentMethods.map((method) => (
                  <div
                    key={method.id}
                    className={`flex items-center gap-4 p-4 rounded-lg border cursor-pointer transition-colors ${
                      selectedPayments.includes(method.id) ? "border-primary bg-primary/5" : "border-border"
                    }`}
                    onClick={() => togglePayment(method.id)}
                  >
                    <Checkbox checked={selectedPayments.includes(method.id)} />
                    <method.icon className="h-5 w-5 text-muted-foreground" />
                    <div className="flex-1">
                      <p className="font-medium">{method.label}</p>
                      <p className="text-sm text-muted-foreground">{method.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Tokenization */}
          <Card>
            <CardHeader>
              <CardTitle>Blockchain Options</CardTitle>
              <CardDescription>Mint your listing as an NFT for additional security and ownership proof</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Enable NFT Tokenization</p>
                  <p className="text-sm text-muted-foreground">
                    Your listing will be minted as an NFT on the blockchain
                  </p>
                </div>
                <Switch
                  checked={formData.is_tokenized}
                  onCheckedChange={(checked) => setFormData({ ...formData, is_tokenized: checked })}
                />
              </div>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex gap-4 justify-end">
            <Link href="/dashboard/listings">
              <Button type="button" variant="outline">
                Cancel
              </Button>
            </Link>
            <Button type="submit" disabled={loading}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Submit for Verification
            </Button>
          </div>
        </div>
      </form>
    </div>
  )
}
