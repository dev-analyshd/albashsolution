import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { applicationId } = await request.json()

    if (!applicationId) {
      return NextResponse.json({ error: "Application ID is required" }, { status: 400 })
    }

    const supabase = await createClient()

    // Query for the application
    // First try to find by the generated ID format (APP-YYYY-XXXXX)
    // If not found, try to find by UUID
    let query = supabase
      .from("applications")
      .select("id, application_type, status, title, created_at, updated_at, reviewed_at, feedback")

    // Check if it's a UUID format or custom ID format
    if (applicationId.startsWith("APP-")) {
      // For custom IDs, we'll search in the title or a custom field
      // Since we don't have a custom application_id field, we'll match against title pattern
      query = query.ilike("title", `%${applicationId}%`)
    } else {
      // Try UUID lookup
      query = query.eq("id", applicationId)
    }

    const { data: application, error } = await query.maybeSingle()

    if (error) {
      console.error("Database error:", error)
      return NextResponse.json({ error: "Failed to check status" }, { status: 500 })
    }

    if (!application) {
      return NextResponse.json({ error: "Application not found" }, { status: 404 })
    }

    // Map database status to display status
    const statusMap: Record<string, string> = {
      pending: "pending",
      under_review: "in_review",
      approved: "approved",
      rejected: "rejected",
      update_required: "needs_update",
    }

    return NextResponse.json({
      success: true,
      application: {
        id: application.id,
        type: application.application_type,
        status: statusMap[application.status] || application.status,
        title: application.title,
        createdAt: application.created_at,
        updatedAt: application.updated_at,
        reviewedAt: application.reviewed_at,
        feedback: application.feedback,
      },
    })
  } catch (error) {
    console.error("Check status error:", error)
    return NextResponse.json({ error: "An unexpected error occurred" }, { status: 500 })
  }
}
